This file was mounted with Camunda 8.6 but is now merged into `./.orchestration/application.yaml` with Camunda 8.8!
